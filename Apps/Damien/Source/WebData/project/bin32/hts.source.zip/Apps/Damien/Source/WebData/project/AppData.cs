﻿namespace hts
{
    public static class AppData
    {
        public static string DataDirectory;
    }
}
