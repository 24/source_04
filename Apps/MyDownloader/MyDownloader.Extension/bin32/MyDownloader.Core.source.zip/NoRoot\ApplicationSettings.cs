using System.Windows.Forms;

namespace MyDownloader.Core.UI
{
    public partial class ApplicationSettings : UserControl
    {
        public ApplicationSettings()
        {
            Text = "Application";
            InitializeComponent();
        }
    }
}
