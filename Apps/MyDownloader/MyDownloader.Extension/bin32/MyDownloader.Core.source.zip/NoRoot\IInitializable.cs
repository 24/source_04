namespace MyDownloader.Core.Extensions
{
    public interface IInitializable
    {
        void Init();
    }
}
