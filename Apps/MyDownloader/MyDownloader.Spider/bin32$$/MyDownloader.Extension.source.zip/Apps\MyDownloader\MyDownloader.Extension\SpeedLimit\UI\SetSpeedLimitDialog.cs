using System.Windows.Forms;

namespace MyDownloader.Extension.SpeedLimit.UI
{
    public partial class SetSpeedLimitDialog : Form
    {
        public SetSpeedLimitDialog()
        {
            InitializeComponent();
        }
    }
}