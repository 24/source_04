﻿namespace pb.IO
{
    public class CompressFile
    {
        public string File;
        public string CompressedFile;
    }
}
