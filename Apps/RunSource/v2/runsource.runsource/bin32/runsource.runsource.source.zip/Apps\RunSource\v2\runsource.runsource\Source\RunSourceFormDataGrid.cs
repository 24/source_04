﻿namespace runsourced
{
    partial class RunSourceForm
    {
        private System.Windows.Forms.DataGrid grid_result3;

        private void InitializeDataGrid()
        {
            this.grid_result3 = new System.Windows.Forms.DataGrid();
            ((System.ComponentModel.ISupportInitialize)(this.grid_result3)).BeginInit();
            // 
            // grid_result3
            // 
            this.grid_result3.DataMember = "";
            this.grid_result3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grid_result3.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grid_result3.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.grid_result3.Location = new System.Drawing.Point(0, 0);
            this.grid_result3.Name = "grid_result3";
            this.grid_result3.Size = new System.Drawing.Size(1048, 364);
            this.grid_result3.TabIndex = 0;
            ((System.ComponentModel.ISupportInitialize)(this.grid_result3)).EndInit();
            this.tab_result3.Controls.Add(this.grid_result3);
        }
    }
}
