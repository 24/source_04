﻿namespace runsourced
{
    partial class RunSourceForm
    {
        private System.Windows.Forms.TreeView tree_result;

        private void InitializeTreeView()
        {
            this.tree_result = new System.Windows.Forms.TreeView();
            // 
            // tree_result
            // 
            this.tree_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tree_result.Location = new System.Drawing.Point(0, 0);
            this.tree_result.Name = "tree_result";
            this.tree_result.Size = new System.Drawing.Size(1048, 364);
            this.tree_result.TabIndex = 0;
            this.tab_result4.Controls.Add(this.tree_result);
        }
    }
}
