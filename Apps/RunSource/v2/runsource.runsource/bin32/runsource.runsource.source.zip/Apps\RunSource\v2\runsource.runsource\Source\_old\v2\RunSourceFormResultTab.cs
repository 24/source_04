﻿namespace runsourced
{
    partial class RunSourceForm
    {
        private System.Windows.Forms.TabControl tc_result;
        private System.Windows.Forms.TabPage tab_result1;
        private System.Windows.Forms.TabPage tab_result2;
        private System.Windows.Forms.TabPage tab_result3;
        private System.Windows.Forms.TabPage tab_result4;
        private System.Windows.Forms.TabPage tab_message;
        private System.Windows.Forms.TextBox tb_message;

        private void CreateResultTab()
        {
            this.tc_result = new System.Windows.Forms.TabControl();
            this.tab_result1 = new System.Windows.Forms.TabPage();
            this.tab_result2 = new System.Windows.Forms.TabPage();
            this.tab_result3 = new System.Windows.Forms.TabPage();
            this.tab_result4 = new System.Windows.Forms.TabPage();
            this.tab_message = new System.Windows.Forms.TabPage();
            this.tb_message = new System.Windows.Forms.TextBox();

            this.tc_result.SuspendLayout();
            this.tab_result1.SuspendLayout();
            this.tab_result2.SuspendLayout();
            this.tab_result3.SuspendLayout();
            this.tab_result4.SuspendLayout();
            this.tab_message.SuspendLayout();

            // 
            // tc_result
            // 
            this.tc_result.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tc_result.Controls.Add(this.tab_result1);
            this.tc_result.Controls.Add(this.tab_result2);
            this.tc_result.Controls.Add(this.tab_result3);
            this.tc_result.Controls.Add(this.tab_result4);
            this.tc_result.Controls.Add(this.tab_message);
            this.tc_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tc_result.Location = new System.Drawing.Point(0, 224);
            this.tc_result.Name = "tc_result";
            this.tc_result.SelectedIndex = 0;
            this.tc_result.Size = new System.Drawing.Size(1056, 390);
            this.tc_result.TabIndex = 2;

            // 
            // tab_result
            // 
            this.tab_result1.Location = new System.Drawing.Point(4, 4);
            this.tab_result1.Name = "tab_result";
            this.tab_result1.Padding = new System.Windows.Forms.Padding(3);
            this.tab_result1.Size = new System.Drawing.Size(1048, 364);
            this.tab_result1.TabIndex = 0;
            this.tab_result1.Text = "Results 1";
            this.tab_result1.UseVisualStyleBackColor = true;

            // 
            // tab_result2
            // 
            this.tab_result2.Location = new System.Drawing.Point(4, 4);
            this.tab_result2.Name = "tab_result2";
            this.tab_result2.Size = new System.Drawing.Size(1048, 364);
            this.tab_result2.TabIndex = 2;
            this.tab_result2.Text = "Results 2";
            this.tab_result2.UseVisualStyleBackColor = true;

            // 
            // tab_result3
            // 
            this.tab_result3.Location = new System.Drawing.Point(4, 4);
            this.tab_result3.Name = "tab_result3";
            this.tab_result3.Size = new System.Drawing.Size(1048, 364);
            this.tab_result3.TabIndex = 3;
            this.tab_result3.Text = "Results 3";
            this.tab_result3.UseVisualStyleBackColor = true;

            // 
            // tab_result4
            // 
            this.tab_result4.Location = new System.Drawing.Point(4, 4);
            this.tab_result4.Name = "tab_result4";
            this.tab_result4.Size = new System.Drawing.Size(1048, 364);
            this.tab_result4.TabIndex = 4;
            this.tab_result4.Text = "Results 4";
            this.tab_result4.UseVisualStyleBackColor = true;

            // 
            // tab_message
            // 
            this.tab_message.Controls.Add(this.tb_message);
            this.tab_message.Location = new System.Drawing.Point(4, 4);
            this.tab_message.Name = "tab_message";
            this.tab_message.Padding = new System.Windows.Forms.Padding(3);
            this.tab_message.Size = new System.Drawing.Size(1048, 364);
            this.tab_message.TabIndex = 1;
            this.tab_message.Text = "Messages";
            this.tab_message.UseVisualStyleBackColor = true;

            // 
            // tb_message
            // 
            this.tb_message.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tb_message.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_message.Location = new System.Drawing.Point(3, 3);
            this.tb_message.Multiline = true;
            this.tb_message.Name = "tb_message";
            this.tb_message.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tb_message.Size = new System.Drawing.Size(1042, 358);
            this.tb_message.TabIndex = 0;
            this.tb_message.WordWrap = false;

            this.Controls.Add(this.tc_result);
            //this.Controls.SetChildIndex(this.tc_result, 1);
            this.tc_result.ResumeLayout(false);
            this.tab_result1.ResumeLayout(false);
            this.tab_result2.ResumeLayout(false);
            this.tab_result3.ResumeLayout(false);
            this.tab_result4.ResumeLayout(false);
            this.tab_message.ResumeLayout(false);
            this.tab_message.PerformLayout();
        }
    }
}
