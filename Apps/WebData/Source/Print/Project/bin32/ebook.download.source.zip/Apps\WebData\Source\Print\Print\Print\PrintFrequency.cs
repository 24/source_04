﻿namespace Download.Print
{
    public enum PrintFrequency
    {
        Unknow = 0,
        Daily,
        Weekly,
        EveryTwoWeek,
        Monthly,
        //TwoMonthly,      // bimensuel
        Bimonthly,       // bimestriel
        Quarterly        // trimestriel
    }
}
