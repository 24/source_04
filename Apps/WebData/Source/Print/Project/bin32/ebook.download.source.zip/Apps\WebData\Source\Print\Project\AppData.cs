﻿using System;

namespace Download.Print
{
    public static class AppData
    {
        public static string DataDirectory;
    }
}
