﻿namespace pb.Data.TraceData
{
    public interface ITraceData
    {
        void ActivateTraceData(TraceData traceData);
        void DesactivateTraceData();
    }
}
