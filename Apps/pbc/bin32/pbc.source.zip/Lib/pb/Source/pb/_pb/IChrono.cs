﻿namespace pb
{
    public interface IChrono
    {
        string TotalTimeString { get; }
    }
}
