﻿namespace pb.Web.Http
{
    public enum XmlDocumentSourceType
    {
        NoSource = 0,
        Http,
        XmlFile,
        HtmlString
    }
}
