﻿namespace pb.Web
{
    public enum XmlDocumentSourceType
    {
        NoSource = 0,
        Http,
        XmlFile,
        HtmlString
    }
}
