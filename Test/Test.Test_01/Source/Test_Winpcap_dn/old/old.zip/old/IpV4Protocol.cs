    // Summary:
    //     Indicates the next level IPv4 protocol used in the pyaload of the IPv4 datagram.
    public enum IpV4Protocol
    {
        // Summary:
        //     IPv6 Hop-by-Hop Option RFC 2460
        IpV6HopByHopOption = 0,
        //
        // Summary:
        //     Internet Control Message Protocol RFC 792
        InternetControlMessageProtocol = 1,
        //
        // Summary:
        //     Internet Group Management Protocol RFC 1112
        InternetGroupManagementProtocol = 2,
        //
        // Summary:
        //     Gateway-to-Gateway Protocol RFC 823
        GatewayToGateway = 3,
        //
        // Summary:
        //     IP in IP (encapsulation) RFC 2003
        Ip = 4,
        //
        // Summary:
        //     Internet Stream Protocol RFC 1190, RFC 1819
        Stream = 5,
        //
        // Summary:
        //     Transmission Control Protocol RFC 793
        Tcp = 6,
        //
        // Summary:
        //     CBT
        Cbt = 7,
        //
        // Summary:
        //     Exterior Gateway Protocol RFC 888
        ExteriorGatewayProtocol = 8,
        //
        // Summary:
        //     Interior Gateway Protocol (any private interior gateway (used by Cisco for
        //     their IGRP))
        InteriorGatewayProtocol = 9,
        //
        // Summary:
        //     BBN RCC Monitoring
        BbnRccMonitoring = 10,
        //
        // Summary:
        //     Network Voice Protocol RFC 741
        NetworkVoice = 11,
        //
        // Summary:
        //     Xerox PUP
        Pup = 12,
        //
        // Summary:
        //     ARGUS
        Argus = 13,
        //
        // Summary:
        //     EMCON
        Emcon = 14,
        //
        // Summary:
        //     Cross Net Debugger IEN 158
        CrossNetDebugger = 15,
        //
        // Summary:
        //     Chaos
        Chaos = 16,
        //
        // Summary:
        //     User Datagram Protocol RFC 768
        Udp = 17,
        //
        // Summary:
        //     Multiplexing IEN 90
        Multiplexing = 18,
        //
        // Summary:
        //     DCN Measurement Subsystems
        DcnMeasurement = 19,
        //
        // Summary:
        //     Host Monitoring Protocol RFC 869
        HostMonitoringProtocol = 20,
        //
        // Summary:
        //     Packet Radio Measurement
        PacketRadioMeasurement = 21,
        //
        // Summary:
        //     XEROX NS IDP
        XeroxNsInternetDatagramProtocol = 22,
        //
        // Summary:
        //     Trunk-1
        Trunk1 = 23,
        //
        // Summary:
        //     Trunk-2
        Trunk2 = 24,
        //
        // Summary:
        //     Leaf-1
        Leaf1 = 25,
        //
        // Summary:
        //     Leaf-2
        Leaf2 = 26,
        //
        // Summary:
        //     Reliable Datagram Protocol RFC 908
        ReliableDatagramProtocol = 27,
        //
        // Summary:
        //     Internet Reliable Transaction Protocol RFC 938
        InternetReliableTransactionProtocol = 28,
        //
        // Summary:
        //     ISO Transport Protocol Class 4 RFC 905
        IsoTransportProtocolClass4 = 29,
        //
        // Summary:
        //     Bulk Data Transfer Protocol RFC 998
        BulkDataTransferProtocol = 30,
        //
        // Summary:
        //     MFE Network Services Protocol
        MagneticFusionEnergyNetworkServicesProtocol = 31,
        //
        // Summary:
        //     MERIT Internodal Protocol
        MeritInternodalProtocol = 32,
        //
        // Summary:
        //     Datagram Congestion Control Protocol RFC 4340
        DatagramCongestionControlProtocol = 33,
        //
        // Summary:
        //     Third Party Connect Protocol
        ThirdPartyConnect = 34,
        //
        // Summary:
        //     Inter-Domain Policy Routing Protocol RFC 1479
        InterDomainPolicyRoutingProtocol = 35,
        //
        // Summary:
        //     Xpress Transport Protocol
        XpressTransportProtocol = 36,
        //
        // Summary:
        //     Datagram Delivery Protocol
        DatagramDeliveryProtocol = 37,
        //
        // Summary:
        //     IDPR Control Message Transport Protocol
        InterDomainPolicyRoutingProtocolControlMessageTransportProtocol = 38,
        //
        // Summary:
        //     TP++ Transport Protocol
        TransportProtocolPlusPlus = 39,
        //
        // Summary:
        //     IL Transport Protocol
        Il = 40,
        //
        // Summary:
        //     IPv6 RFC 2460
        IpV6 = 41,
        //
        // Summary:
        //     Source Demand Routing Protocol
        SourceDemandRoutingProtocol = 42,
        //
        // Summary:
        //     Routing Header for IPv6 RFC 2460
        IpV6Route = 43,
        //
        // Summary:
        //     Fragment Header for IPv6 RFC 2460
        FragmentHeaderForIpV6 = 44,
        //
        // Summary:
        //     Inter-Domain Routing Protocol
        InterDomainRoutingProtocol = 45,
        //
        // Summary:
        //     Resource Reservation Protocol
        Rsvp = 46,
        //
        // Summary:
        //     Generic Routing Encapsulation
        Gre = 47,
        //
        // Summary:
        //     Mobile Host Routing Protocol
        MobileHostRoutingProtocol = 48,
        //
        // Summary:
        //     BNA
        Bna = 49,
        //
        // Summary:
        //     Encapsulating Security Payload RFC 2406
        Esp = 50,
        //
        // Summary:
        //     Authentication Header RFC 2402
        AuthenticationHeader = 51,
        //
        // Summary:
        //     Integrated Net Layer Security Protocol TUBA
        IntegratedNetLayerSecurityProtocol = 52,
        //
        // Summary:
        //     IP with Encryption
        Swipe = 53,
        //
        // Summary:
        //     NBMA Address Resolution Protocol RFC 1735
        NArp = 54,
        //
        // Summary:
        //     IP Mobility (Min Encap) RFC 2004
        Mobile = 55,
        //
        // Summary:
        //     Transport Layer Security Protocol (using Kryptonet key management)
        TransportLayerSecurityProtocol = 56,
        //
        // Summary:
        //     Simple Key-Management for Internet Protocol RFC 2356
        Skip = 57,
        //
        // Summary:
        //     ICMP for IPv6 RFC 2460
        InternetControlMessageProtocolForIpV6 = 58,
        //
        // Summary:
        //     No Next Header for IPv6 RFC 2460
        NoNextHeaderForIpV6 = 59,
        //
        // Summary:
        //     Destination Options for IPv6 RFC 2460
        IpV6Opts = 60,
        //
        // Summary:
        //     Any host internal protocol
        AnyHostInternal = 61,
        //
        // Summary:
        //     CFTP
        Cftp = 62,
        //
        // Summary:
        //     Any local network
        AnyLocalNetwork = 63,
        //
        // Summary:
        //     SATNET and Backroom EXPAK
        SatnetAndBackroomExpak = 64,
        //
        // Summary:
        //     Kryptolan
        Kryptolan = 65,
        //
        // Summary:
        //     MIT Remote Virtual Disk Protocol
        RemoteVirtualDiskProtocol = 66,
        //
        // Summary:
        //     Internet Pluribus Packet Core
        InternetPluribusPacketCore = 67,
        //
        // Summary:
        //     Any distributed file system
        AnyDistributedFileSystem = 68,
        //
        // Summary:
        //     SATNET Monitoring
        SatMon = 69,
        //
        // Summary:
        //     VISA Protocol
        Visa = 70,
        //
        // Summary:
        //     Internet Packet Core Utility
        InternetPacketCoreUtility = 71,
        //
        // Summary:
        //     Computer Protocol Network Executive
        ComputerProtocolNetworkExecutive = 72,
        //
        // Summary:
        //     Computer Protocol Heart Beat
        ComputerProtocolHeartbeat = 73,
        //
        // Summary:
        //     Wang Span Network
        WangSpanNetwork = 74,
        //
        // Summary:
        //     Packet Video Protocol
        PacketVideoProtocol = 75,
        //
        // Summary:
        //     Backroom SATNET Monitoring
        BackroomSatMon = 76,
        //
        // Summary:
        //     SUN ND PROTOCOL-Temporary
        SunNd = 77,
        //
        // Summary:
        //     WIDEBAND Monitoring
        WidebandMonitoring = 78,
        //
        // Summary:
        //     WIDEBAND EXPAK
        WidebandExpak = 79,
        //
        // Summary:
        //     International Organization for Standardization Internet Protocol
        IsoIp = 80,
        //
        // Summary:
        //     Versatile Message Transaction Protocol RFC 1045
        VersatileMessageTransactionProtocol = 81,
        //
        // Summary:
        //     Secure Versatile Message Transaction Protocol RFC 1045
        SecureVersatileMessageTransactionProtocol = 82,
        //
        // Summary:
        //     VINES
        Vines = 83,
        //
        // Summary:
        //     TTP
        Ttp = 84,
        //
        // Summary:
        //     NSFNET-IGP
        NationalScienceFoundationNetworkInteriorGatewayProtocol = 85,
        //
        // Summary:
        //     Dissimilar Gateway Protocol
        DissimilarGatewayProtocol = 86,
        //
        // Summary:
        //     TCF
        Tcf = 87,
        //
        // Summary:
        //     Enhanced Interior Gateway Routing Protocol
        EnhancedInteriorGatewayRoutingProtocol = 88,
        //
        // Summary:
        //     Open Shortest Path First RFC 1583
        OpenShortestPathFirst = 89,
        //
        // Summary:
        //     Sprite RPC Protocol
        SpriteRpc = 90,
        //
        // Summary:
        //     Locus Address Resolution Protocol
        LArp = 91,
        //
        // Summary:
        //     Multicast Transport Protocol
        MulticastTransportProtocol = 92,
        //
        // Summary:
        //     AX.25
        Ax25 = 93,
        //
        // Summary:
        //     IP-within-IP Encapsulation Protocol
        IpIp = 94,
        //
        // Summary:
        //     Mobile Internetworking Control Protocol
        MobileInternetworkingControlProtocol = 95,
        //
        // Summary:
        //     Semaphore Communications Sec. Pro
        SemaphoreCommunicationsSecondProtocol = 96,
        //
        // Summary:
        //     Ethernet-within-IP Encapsulation RFC 3378
        EtherIp = 97,
        //
        // Summary:
        //     Encapsulation Header RFC 1241
        EncapsulationHeader = 98,
        //
        // Summary:
        //     Any private encryption scheme
        AnyPrivateEncryptionScheme = 99,
        //
        // Summary:
        //     GMTP
        Gmtp = 100,
        //
        // Summary:
        //     Ipsilon Flow Management Protocol
        IpsilonFlowManagementProtocol = 101,
        //
        // Summary:
        //     PNNI over IP
        PrivateNetworkToNetworkInterface = 102,
        //
        // Summary:
        //     Protocol Independent Multicast
        Pin = 103,
        //
        // Summary:
        //     ARIS
        Aris = 104,
        //
        // Summary:
        //     SCPS (Space Communications Protocol Standards)
        SpaceCommunicationsProtocolStandards = 105,
        //
        // Summary:
        //     QNX
        Qnx = 106,
        //
        // Summary:
        //     Active Networks
        ActiveNetworks = 107,
        //
        // Summary:
        //     IP Payload Compression Protocol RFC 3173
        IpComp = 108,
        //
        // Summary:
        //     Sitara Networks Protocol
        SitaraNetworksProtocol = 109,
        //
        // Summary:
        //     Compaq Peer Protocol
        CompaqPeer = 110,
        //
        // Summary:
        //     IPX in IP
        InternetworkPacketExchangeInIp = 111,
        //
        // Summary:
        //     Virtual Router Redundancy Protocol, Common Address Redundancy Protocol (not
        //     IANA assigned) VRRP:RFC 3768
        VirtualRouterRedundancyProtocol = 112,
        //
        // Summary:
        //     PGM Reliable Transport Protocol RFC 3208
        PragmaticGeneralMulticastTransportProtocol = 113,
        //
        // Summary:
        //     Any 0-hop protocol
        Any0HopProtocol = 114,
        //
        // Summary:
        //     Layer Two Tunneling Protocol
        LayerTwoTunnelingProtocol = 115,
        //
        // Summary:
        //     D-II Data Exchange (DDX)
        DiiDataExchange = 116,
        //
        // Summary:
        //     Interactive Agent Transfer Protocol
        InteractiveAgentTransferProtocol = 117,
        //
        // Summary:
        //     Schedule Transfer Protocol
        ScheduleTransferProtocol = 118,
        //
        // Summary:
        //     SpectraLink Radio Protocol
        SpectraLinkRadioProtocol = 119,
        //
        // Summary:
        //     UTI
        Uti = 120,
        //
        // Summary:
        //     Simple Message Protocol
        SimpleMessageProtocol = 121,
        //
        // Summary:
        //     SM
        Sm = 122,
        //
        // Summary:
        //     Performance Transparency Protocol
        PerformanceTransparencyProtocol = 123,
        //
        // Summary:
        //     IS-IS over IPv4
        IsIsOverIpV4 = 124,
        //
        Fire = 125,
        //
        // Summary:
        //     Combat Radio Transport Protocol
        CombatRadioTransportProtocol = 126,
        //
        // Summary:
        //     Combat Radio User Datagram
        CombatRadioUserDatagram = 127,
        //
        ServiceSpecificConnectionOrientedProtocolInAMultilinkAndConnectionlessEnvironment = 128,
        //
        Iplt = 129,
        //
        // Summary:
        //     Secure Packet Shield
        SecurePacketShield = 130,
        //
        // Summary:
        //     Private IP Encapsulation within IP Expired I-D draft-petri-mobileip-pipe-00.txt
        Pipe = 131,
        //
        // Summary:
        //     Stream Control Transmission Protocol
        StreamControlTransmissionProtocol = 132,
        //
        // Summary:
        //     Fibre Channel
        FibreChannel = 133,
        //
        // Summary:
        //     RSVP-E2E-IGNORE RFC 3175
        RsvpE2EIgnore = 134,
        //
        // Summary:
        //     Mobility Header RFC 3775
        MobilityHeader = 135,
        //
        // Summary:
        //     UDP Lite RFC 3828
        UdpLite = 136,
        //
        // Summary:
        //     MPLS-in-IP RFC 4023
        MultiprotocolLabelSwitchingInIp = 137,
        //
        // Summary:
        //     MANET Protocols I-D draft-ietf-manet-iana-07.txt
        MobileAdHocNetwork = 138,
        //
        // Summary:
        //     Host Identity Protocol RFC 5201
        Hip = 139,
    }
