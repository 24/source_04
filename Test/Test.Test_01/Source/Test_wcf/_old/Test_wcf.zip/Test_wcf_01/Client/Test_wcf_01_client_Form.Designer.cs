﻿namespace Test_wcf_01.client
{
    partial class Test_wcf_01_client_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_set_text = new System.Windows.Forms.Button();
            this.bt_get_text = new System.Windows.Forms.Button();
            this.lb_set_text = new System.Windows.Forms.Label();
            this.tb_set_text = new System.Windows.Forms.TextBox();
            this.lb_get_text = new System.Windows.Forms.Label();
            this.bt_open_service = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_set_text
            // 
            this.bt_set_text.Location = new System.Drawing.Point(22, 44);
            this.bt_set_text.Name = "bt_set_text";
            this.bt_set_text.Size = new System.Drawing.Size(75, 23);
            this.bt_set_text.TabIndex = 0;
            this.bt_set_text.Text = "&Set text";
            this.bt_set_text.UseVisualStyleBackColor = true;
            this.bt_set_text.Click += new System.EventHandler(this.bt_set_text_Click);
            // 
            // bt_get_text
            // 
            this.bt_get_text.Location = new System.Drawing.Point(369, 44);
            this.bt_get_text.Name = "bt_get_text";
            this.bt_get_text.Size = new System.Drawing.Size(75, 23);
            this.bt_get_text.TabIndex = 1;
            this.bt_get_text.Text = "&Get text";
            this.bt_get_text.UseVisualStyleBackColor = true;
            this.bt_get_text.Click += new System.EventHandler(this.bt_get_text_Click);
            // 
            // lb_set_text
            // 
            this.lb_set_text.AutoSize = true;
            this.lb_set_text.Location = new System.Drawing.Point(19, 84);
            this.lb_set_text.Name = "lb_set_text";
            this.lb_set_text.Size = new System.Drawing.Size(49, 13);
            this.lb_set_text.TabIndex = 2;
            this.lb_set_text.Text = "Set text :";
            // 
            // tb_set_text
            // 
            this.tb_set_text.AcceptsReturn = true;
            this.tb_set_text.Location = new System.Drawing.Point(22, 110);
            this.tb_set_text.Name = "tb_set_text";
            this.tb_set_text.Size = new System.Drawing.Size(204, 20);
            this.tb_set_text.TabIndex = 3;
            this.tb_set_text.Text = "toto tata";
            // 
            // lb_get_text
            // 
            this.lb_get_text.AutoSize = true;
            this.lb_get_text.Location = new System.Drawing.Point(366, 84);
            this.lb_get_text.Name = "lb_get_text";
            this.lb_get_text.Size = new System.Drawing.Size(50, 13);
            this.lb_get_text.TabIndex = 4;
            this.lb_get_text.Text = "Get text :";
            // 
            // bt_open_service
            // 
            this.bt_open_service.Location = new System.Drawing.Point(22, 12);
            this.bt_open_service.Name = "bt_open_service";
            this.bt_open_service.Size = new System.Drawing.Size(116, 23);
            this.bt_open_service.TabIndex = 5;
            this.bt_open_service.Text = "&Open service";
            this.bt_open_service.UseVisualStyleBackColor = true;
            this.bt_open_service.Click += new System.EventHandler(this.bt_open_service_Click);
            // 
            // Test_wcf_01_client_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 273);
            this.Controls.Add(this.bt_open_service);
            this.Controls.Add(this.lb_get_text);
            this.Controls.Add(this.tb_set_text);
            this.Controls.Add(this.lb_set_text);
            this.Controls.Add(this.bt_get_text);
            this.Controls.Add(this.bt_set_text);
            this.Name = "Test_wcf_01_client_Form";
            this.Text = "Test_wcf_01_client_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_set_text;
        private System.Windows.Forms.Button bt_get_text;
        private System.Windows.Forms.Label lb_set_text;
        private System.Windows.Forms.TextBox tb_set_text;
        private System.Windows.Forms.Label lb_get_text;
        private System.Windows.Forms.Button bt_open_service;
    }
}