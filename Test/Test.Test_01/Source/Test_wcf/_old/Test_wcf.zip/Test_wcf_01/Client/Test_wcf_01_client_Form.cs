﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.Text;
using System.Windows.Forms;
using PB_Util;

namespace Test_wcf_01.client
{
    public partial class Test_wcf_01_client_Form : Form
    {
        protected ChannelFactory<IService01> _channelFactory = null;
        protected IService01 _service = null;

        public Test_wcf_01_client_Form()
        {
            InitializeComponent();
        }

        private void OpenService()
        {
            //_channelFactory = new ChannelFactory<IService01>("ConfigurationHttpServiceTest01");

            //string contract = "Test_wcf.IService01";
            //string contract = "IService01";
            //string address = "http://localhost:8018/Test_wcf_01_Service01";
            string address = "http://localhost:8701/Test_wcf_01_Service01";
            //ContractDescription contractDescription = new ContractDescription(contract);
            ContractDescription contractDescription = ContractDescription.GetContract(typeof(IService01));
            WSHttpBinding binding = new WSHttpBinding();
            EndpointAddress endpointAddress = new EndpointAddress(new Uri(address));
            ServiceEndpoint endpoint = new ServiceEndpoint(contractDescription, binding, endpointAddress);
            _channelFactory = new ChannelFactory<IService01>(endpoint);

            _service = _channelFactory.CreateChannel();
        }

        private void bt_set_text_Click(object sender, EventArgs e)
        {
            //ChannelFactory<IService01> channelFactory = null;
            //IService01 service = null;
            try
            {
                //channelFactory = new ChannelFactory<IService01>("ConfigurationHttpServiceTest01");
                //service = channelFactory.CreateChannel();
                string text = tb_set_text.Text;
                _service.SetText(text);
                this.lb_set_text.Text = "set text : \"" + text + "\"";
                text = _service.GetText();
                this.lb_get_text.Text = "get text : \"" + text + "\"";
            }
            catch (Exception ex)
            {
                if (_channelFactory != null)
                    _channelFactory.Abort();
                this.lb_set_text.Text = "error in set text";
                string msg = Error.GetErrorMessage(ex);
                Trace.CurrentTrace.WriteLine(msg);
                MessageBox.Show(msg, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_get_text_Click(object sender, EventArgs e)
        {
            //ChannelFactory<IService01> channelFactory = null;
            //IService01 service = null;
            try
            {
                //channelFactory = new ChannelFactory<IService01>("ConfigurationHttpServiceTest01");
                //service = channelFactory.CreateChannel();
                string text = _service.GetText();
                this.lb_get_text.Text = "get text : \"" + text + "\"";
            }
            catch (Exception ex)
            {
                _channelFactory.Abort();
                this.lb_get_text.Text = "error in get text";
                string msg = Error.GetErrorMessage(ex);
                Trace.CurrentTrace.WriteLine(msg);
                MessageBox.Show(msg, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_open_service_Click(object sender, EventArgs e)
        {
            try
            {
                OpenService();
            }
            catch (Exception ex)
            {
                string msg = Error.GetErrorMessage(ex);
                Trace.CurrentTrace.WriteLine(msg);
                MessageBox.Show(msg, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
