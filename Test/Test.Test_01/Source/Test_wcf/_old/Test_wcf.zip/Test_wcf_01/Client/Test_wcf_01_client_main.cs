﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using PB_Util;

namespace Test_wcf_01.client
{
    public class main
    {
        public static void Main()
        {
            //AssemblyResolve.Add("Test_wcf_service01_dll.dll", "Test_wcf_service01_dll, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null");
            Trace.CurrentTrace.SetLogFile("log_client.txt", LogOptions.None);
            Trace.CurrentTrace.WriteLine("Test_wcf_01_client.exe started");
            Application.Run(new Test_wcf_01_client_Form());
        }
    }
}
