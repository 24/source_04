﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace Test_wcf_01
{
    //[ServiceContract(Namespace = "toto")]
    //[ServiceContract()]
    [ServiceContract(SessionMode = SessionMode.Required)]
    public interface IService01
    {
        [OperationContract()]
        string GetText();

        [OperationContract()]
        void SetText(string text);
    }
}
