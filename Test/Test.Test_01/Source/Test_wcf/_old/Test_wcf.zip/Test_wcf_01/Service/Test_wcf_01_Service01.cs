﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace Test_wcf_01.service
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    //[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    class Service01 : IService01
    {
        protected string _text = null;

        public string GetText()
        {
            return _text;
        }

        public void SetText(string text)
        {
            _text = text;
        }
    }
}
