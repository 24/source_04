﻿namespace Test_wcf_01.service
{
    partial class Test_wcf_01_service_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_start_service = new System.Windows.Forms.Button();
            this.bt_stop_service = new System.Windows.Forms.Button();
            this.lb_service = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // bt_start_service
            // 
            this.bt_start_service.Location = new System.Drawing.Point(22, 44);
            this.bt_start_service.Name = "bt_start_service";
            this.bt_start_service.Size = new System.Drawing.Size(75, 23);
            this.bt_start_service.TabIndex = 0;
            this.bt_start_service.Text = "&Start service";
            this.bt_start_service.UseVisualStyleBackColor = true;
            this.bt_start_service.Click += new System.EventHandler(this.bt_start_service_Click);
            // 
            // bt_stop_service
            // 
            this.bt_stop_service.Location = new System.Drawing.Point(143, 44);
            this.bt_stop_service.Name = "bt_stop_service";
            this.bt_stop_service.Size = new System.Drawing.Size(75, 23);
            this.bt_stop_service.TabIndex = 1;
            this.bt_stop_service.Text = "St&op service";
            this.bt_stop_service.UseVisualStyleBackColor = true;
            this.bt_stop_service.Click += new System.EventHandler(this.bt_stop_service_Click);
            // 
            // lb_service
            // 
            this.lb_service.AutoSize = true;
            this.lb_service.Location = new System.Drawing.Point(52, 117);
            this.lb_service.Name = "lb_service";
            this.lb_service.Size = new System.Drawing.Size(94, 13);
            this.lb_service.TabIndex = 2;
            this.lb_service.Text = "Service is stopped";
            // 
            // Test_wcf_01_service_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.Add(this.lb_service);
            this.Controls.Add(this.bt_stop_service);
            this.Controls.Add(this.bt_start_service);
            this.Name = "Test_wcf_01_service_Form";
            this.Text = "Test_wcf_01_service_Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_start_service;
        private System.Windows.Forms.Button bt_stop_service;
        private System.Windows.Forms.Label lb_service;
    }
}