RunSource.CurrentRunSource.Compile_Project(@"Service\Test_wcf_01_service_project.xml");
RunSource.CurrentRunSource.Compile_Project(@"Client\Test_wcf_01_client_project.xml");


Test_01();
