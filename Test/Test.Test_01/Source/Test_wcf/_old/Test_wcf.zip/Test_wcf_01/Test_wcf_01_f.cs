﻿using System;
using System.Collections.Generic;
//using System.ServiceModel;
using System.Text;
using PB_Util;

namespace Test_wcf_01
{

    // Introduction à Windows Communication Foundation http://webman.developpez.com/articles/dotnet/wcf/intro/

    static partial class w
    {
        private static ITrace _tr = Trace.CurrentTrace;
        private static RunSource _wr = RunSource.CurrentRunSource;

        public static void Init()
        {
        }

        public static void End()
        {
        }

        public static void Test_01()
        {
            _tr.WriteLine("Test_01");
        }
    }
}
