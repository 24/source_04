﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test_wcf_02.client
{
    public partial class Form1 : Form
    {
        private static Form1 _current = null;
        //Test_wcf_sol_02_Service
        //private Test_wcf_sol_02_Service.RequestCallback _test_wcf_sol_02_Service_RequestCallback = null;
        private Test_wcf_sol_02_Service.ServiceClient _test_wcf_sol_02_Service = null;
        //private Test_wcf_02_Service01.RequestCallback _test_wcf_02_Service01_RequestCallback = null;
        private Test_wcf_02_Service01.Service01Client _test_wcf_02_Service01 = null;
        private Test_wcf_02_Service02.Service02Client _test_wcf_02_Service02 = null;

        public static Form1 Current
        {
            get { return _current; }
        }

        public Form1()
        {
            _current = this;
            this.Icon = Program.Icon;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void InitTest_wcf_sol_02_Service()
        {
            if (_test_wcf_sol_02_Service == null)
            {
                WriteLine("call init Test_wcf_sol_02_Service begin");
                Test_wcf_sol_02_Service.RequestCallback requestCallback = new Test_wcf_sol_02_Service.RequestCallback();
                InstanceContext requestCallbackInstance = new InstanceContext(requestCallback);
                _test_wcf_sol_02_Service = new Test_wcf_sol_02_Service.ServiceClient(requestCallbackInstance);
                WriteLine("call init Test_wcf_sol_02_Service end");
            }
        }

        private void InitTest_wcf_02_Service01()
        {
            if (_test_wcf_02_Service01 == null)
            {
                WriteLine("call init Test_wcf_02_Service01 begin");
                Test_wcf_02_Service01.RequestCallback requestCallback = new Test_wcf_02_Service01.RequestCallback();
                InstanceContext requestCallbackInstance = new InstanceContext(requestCallback);
                _test_wcf_02_Service01 = new Test_wcf_02_Service01.Service01Client(requestCallbackInstance);
                WriteLine("call init Test_wcf_02_Service01 end");
            }
        }

        private void InitTest_wcf_02_Service02()
        {
            if (_test_wcf_02_Service02 == null)
            {
                WriteLine("call init Test_wcf_02_Service02 begin");
                Test_wcf_02_Service02.RequestCallback requestCallback = new Test_wcf_02_Service02.RequestCallback();
                InstanceContext requestCallbackInstance = new InstanceContext(requestCallback);
                _test_wcf_02_Service02 = new Test_wcf_02_Service02.Service02Client(requestCallbackInstance);
                WriteLine("call init Test_wcf_02_Service02 end");
            }
        }

        private void bt_get_data1_Click(object sender, EventArgs e)
        {
            InitTest_wcf_sol_02_Service();
            WriteLine("call Test_wcf_sol_02_Service.GetData begin");
            _test_wcf_sol_02_Service.GetData("toto", "toto");
            WriteLine("call Test_wcf_sol_02_Service.GetData end");
        }

        private void bt_get_data2_Click(object sender, EventArgs e)
        {
            InitTest_wcf_02_Service01();
            WriteLine("call Test_wcf_02_Service01.GetData begin");
            _test_wcf_02_Service01.GetData("toto", "toto");
            WriteLine("call Test_wcf_02_Service01.GetData end");
        }

        private void bt_get_data3_Click(object sender, EventArgs e)
        {
            InitTest_wcf_02_Service02();
            WriteLine("call Test_wcf_02_Service02.GetMessages begin");
            _test_wcf_02_Service02.GetMessages();
            WriteLine("call Test_wcf_02_Service02.GetMessages end");
        }

        public void SetData(object dataSource)
        {
            //departmentBindingSource.Clear();
            //foreach (Department department in departments)
            //    departmentBindingSource.Add(department);
            dgv_data.DataSource = dataSource;
        }

        public void Write(string message, params object[] prm)
        {
            if (prm.Length > 0)
                message = string.Format(message, prm);
            tb_log.AppendText(message);
        }

        public void WriteLine(string message, params object[] prm)
        {
            if (prm.Length > 0)
                message = string.Format(message, prm);
            tb_log.AppendText(message + "\r\n");
        }
    }
}
