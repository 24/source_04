﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

//WCF_Callback_Service_Client.ServiceReference2
namespace Test_wcf_02.client.Test_wcf_02_Service01
{
    public class RequestCallback : IService01Callback
    {
        private Department[] _departments;

        public Department[] Departments
        {
            get { return _departments; }
            set { _departments = value; }
        }

        public void SendResult(Department[] departments)
        {
            _departments = departments;
            Form1.Current.WriteLine("receive {0} departments from Test_wcf_02_Service01", departments.Length);
            Form1.Current.SetData(departments);
            //MessageBox.Show(string.Format("receive {0} departments", departments.Length));
        }
    }
}
