﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

//WCF_Callback_Service_Client.ServiceReference2
namespace Test_wcf_02.client.Test_wcf_02_Service02
{
    public class RequestCallback : IService02Callback
    {
        public void SendMessage(string message)
        {
            Form1.Current.WriteLine("receive message from Test_wcf_02_Service02 : \"{0}\"", message);
        }
    }
}
