﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;

namespace Test_wcf_02.client.Test_wcf_sol_02_Service
{
    public class RequestCallback : IServiceCallback
    {
        private Department[] _departments;

        public Department[] Departments
        {
            get { return _departments; }
            set { _departments = value; }
        }

        public void SendResult(Department[] departments)
        {
            _departments = departments;
            Form1.Current.WriteLine("receive {0} departments from Test_wcf_sol_02_Service", departments.Length);
            Form1.Current.SetData(departments);
            //MessageBox.Show(string.Format("receive {0} departments", departments.Length));
        }
    }
}
