﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
//using System.ServiceModel.Web;
using System.Text;

//namespace WCF_Callback_Service
namespace Test_wcf_02.service
{
    //[ServiceContract]
    [ServiceContract(SessionMode = SessionMode.Required, CallbackContract = typeof(IService01Callback))]
    public interface IService01
    {
        //[OperationContract]
        //string GetData(int value);
        [OperationContract(IsOneWay = true)]
        void GetData(string userName, string password);

        //[OperationContract]
        //CompositeType GetDataUsingDataContract(CompositeType composite);
    }

    public interface IService01Callback
    {
        [OperationContract(IsOneWay = true)]
        void SendResult(Department[] departments);
    }

    [DataContract]
    public class Department
    {
        public int No { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int Capacity { get; set; }
    }

    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }
}
