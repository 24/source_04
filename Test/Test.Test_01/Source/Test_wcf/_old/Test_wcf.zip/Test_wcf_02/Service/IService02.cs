﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
//using System.ServiceModel.Web;
using System.Text;

namespace Test_wcf_02.service
{
    [ServiceContract(SessionMode = SessionMode.Required, CallbackContract = typeof(IService02Callback))]
    public interface IService02
    {
        [OperationContract(IsOneWay = true)]
        void GetMessages();
    }

    public interface IService02Callback
    {
        [OperationContract(IsOneWay = true)]
        void SendMessage(string message);
    }
}
