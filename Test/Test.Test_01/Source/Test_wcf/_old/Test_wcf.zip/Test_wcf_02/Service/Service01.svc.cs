﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

//http://localhost:8802/test_wcf_02/Service01.svc

namespace Test_wcf_02.service
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class Service01 : IService01
    {
        public IService01Callback Callback
        {
            get
            {
                return OperationContext.Current.GetCallbackChannel<IService01Callback>();
            }
        }

        //public string GetData(int value)
        //{
        //    return string.Format("You entered: {0}", value);
        //}

        public void GetData(string userName, string password)
        {
            Department[] departments = new Department[]
            {
                new Department() { No = 10, Name = "IT", Capacity = 4500 },
                new Department() { No = 20, Name = "HRD", Capacity = 200 },
                new Department() { No = 30, Name = "ACCTS", Capacity = 40 }
            };

            if (userName == "toto" && password == "toto")
            {
                Thread.Sleep(10000);
                Callback.SendResult(departments);
            }
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
