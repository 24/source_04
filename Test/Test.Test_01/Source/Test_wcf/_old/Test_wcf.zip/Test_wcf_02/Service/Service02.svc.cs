﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading;

//http://localhost:8802/test_wcf_02/Service02.svc

namespace Test_wcf_02.service
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class Service02 : IService02
    {
        private int _messageNo = 1;
        public IService02Callback Callback
        {
            get
            {
                return OperationContext.Current.GetCallbackChannel<IService02Callback>();
            }
        }

        public void GetMessages()
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(100);
                Callback.SendMessage(string.Format("service message no {0}", _messageNo++));
            }
        }

        //public CompositeType GetDataUsingDataContract(CompositeType composite)
        //{
        //    if (composite == null)
        //    {
        //        throw new ArgumentNullException("composite");
        //    }
        //    if (composite.BoolValue)
        //    {
        //        composite.StringValue += "Suffix";
        //    }
        //    return composite;
        //}
    }
}
