RunSource.CurrentRunSource.Compile_Project(@"Service\Test_wcf_02_service_project.xml");
RunSource.CurrentRunSource.Compile_Project(@"Client\Test_wcf_02_client_project.xml");

Compiler.TraceLevel = 1;
Compiler.TraceLevel = 2;

Test_01();
_tr.WriteLine(Path.Combine(@"c:\toto", @"data\tata.txt"));
_tr.WriteLine(Path.Combine(@"c:\toto", @"c:\data\tata.txt"));






RunSource.CurrentRunSource.Compile_Project(@"runsource_dll\irunsource_project.xml");
RunSource.CurrentRunSource.Compile_Project(@"runsource_dll\runsource_dll_project.xml");
RunSource.CurrentRunSource.Compile_Project(@"runsource_domain\runsourced32_project.xml");
