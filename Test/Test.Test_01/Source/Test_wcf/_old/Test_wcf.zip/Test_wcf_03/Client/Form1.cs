﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test_wcf_03.Client
{
    public partial class Form1 : Form
    {
        private static Form1 _current = null;
        //private Test_wcf_sol_02_Service.ServiceClient _test_wcf_sol_02_Service = null;
        private exe.Service01.Service01Client _test_wcf_03_exe_Service01 = null;

        public static Form1 Current
        {
            get { return _current; }
        }

        public Form1()
        {
            _current = this;
            this.Icon = Program.Icon;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void InitTest_wcf_03_exe_Service01()
        {
            if (_test_wcf_03_exe_Service01 == null)
            {
                WriteLine("call init exe.Service01 begin");
                _test_wcf_03_exe_Service01 = new Test_wcf_03.Client.exe.Service01.Service01Client();
                WriteLine("call init exe.Service01 end");
            }
        }

        private void bt_get_data1_Click(object sender, EventArgs e)
        {
            InitTest_wcf_03_exe_Service01();
            WriteLine("call exe.Service01.GetEmployeeXML() begin");
            exe.Service01.EmployeeXML employeeXML = _test_wcf_03_exe_Service01.GetEmployeeXML();
            WriteLine("  employeeXML.Id     {0}", employeeXML.Id);
            WriteLine("  employeeXML.Name   {0}", employeeXML.Name);
            WriteLine("  employeeXML.Salary {0}", employeeXML.Salary);
            WriteLine("call exe.Service01.GetEmployeeXML() end");
        }

        public void Write(string message, params object[] prm)
        {
            if (prm.Length > 0)
                message = string.Format(message, prm);
            tb_log.AppendText(message);
        }

        public void WriteLine(string message, params object[] prm)
        {
            if (prm.Length > 0)
                message = string.Format(message, prm);
            tb_log.AppendText(message + "\r\n");
        }
    }
}
