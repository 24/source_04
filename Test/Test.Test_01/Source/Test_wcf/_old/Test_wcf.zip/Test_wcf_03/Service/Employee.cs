﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Test_wcf_03.Service
{
    [DataContract]
    public class EmployeeXML
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public double Salary { get; set; }
    }

    [DataContract]
    public class EmployeeJSON
    {
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int Id { get; set; }

        [DataMember]
        public double Salary { get; set; }
    }
}
