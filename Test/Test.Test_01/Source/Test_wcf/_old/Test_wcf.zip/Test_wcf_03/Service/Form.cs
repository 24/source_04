﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
//using System.Data;
using System.Drawing;
using System.ServiceModel;
using System.Text;
using System.Windows.Forms;
using PB_Util;

namespace Test_wcf_03.Service
{
    // http://stackoverflow.com/questions/11646704/wcf-service-access-right-no-access-rights-to-this-namespace
    // netsh http add urlacl http://+:4711/ user=DOMAIN\USER
    // netsh http add urlacl http://+:8018/ user=\Everyone
    // netsh http show urlacl

    // @Echo Parameter 1 "%1" == port
    // @Echo Parameter 2 "%2" == URL
    // netsh http add urlacl url=http://+:%1/%2 user=%USERDOMAIN%\%USERNAME%
    // HTTP Server API Version 1.0 Reference : HttpSetServiceConfiguration function http://msdn.microsoft.com/en-us/library/aa364503%28v=vs.85%29.aspx

    public partial class ServiceForm : Form
    {
        protected ServiceHost _host;

        public ServiceForm()
        {
            InitializeComponent();
        }

        private void bt_start_service_Click(object sender, EventArgs e)
        {

            try
            {
                _host = new ServiceHost(typeof(Service01));
                _host.Open();
                this.bt_start_service.Enabled = false;
                this.lb_service.Text = "Service is started";
                Trace.CurrentTrace.WriteLine("Service is started");
            }
            catch (Exception ex)
            {
                this.bt_start_service.Enabled = true;
                this.lb_service.Text = "Service can't be started";
                string msg = Error.GetErrorMessage(ex);
                Trace.CurrentTrace.WriteLine(msg);
                MessageBox.Show(msg, "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_stop_service_Click(object sender, EventArgs e)
        {
            if (_host.State == CommunicationState.Opened | _host.State == CommunicationState.Faulted | _host.State == CommunicationState.Opening)
            {

                _host.Close();
                this.bt_start_service.Enabled = true;
                this.lb_service.Text = "Service is stopped";
                Trace.CurrentTrace.WriteLine("Service is stopped");
            }
        }
    }
}
