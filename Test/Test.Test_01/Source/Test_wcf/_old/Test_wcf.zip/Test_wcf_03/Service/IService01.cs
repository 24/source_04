﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Test_wcf_03.Service
{
    [ServiceContract]
    public interface IService01
    {
        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "GetXml", ResponseFormat = WebMessageFormat.Xml, RequestFormat = WebMessageFormat.Xml, BodyStyle = WebMessageBodyStyle.Bare)]
        EmployeeXML GetEmployeeXML();

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "GetJson", ResponseFormat = WebMessageFormat.Json, RequestFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        EmployeeJSON GetEmployeeJSON();
    }
}
