﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Activation;
using System.Text;
using PB_Util;

// service : exe 8703
//   http://localhost:8703/Test_wcf_03_Service01          Test_wcf_03.Client.exe.Service01
// service : IIS dll 8803
//   http://localhost:8803/Test_wcf_03_Service01.svc      Test_wcf_03.Client.iis.Service01




//http://localhost:8803/test_wcf_03/Service01.svc
//http://localhost:8803/test_wcf_03/Service01.svc/GetXml
//http://localhost:8803/test_wcf_03/Service01.svc/GetJson
// Origin http://localhost:1716 is not allowed by Access-Control-Allow-Origin http://stackoverflow.com/questions/9816591/origin-http-localhost1716-is-not-allowed-by-access-control-allow-origin
// You'll need to enable Cross Origin Resource Sharing on the service that runs on port 1716
// add this to Web.config
//<system.webServer>
//  <modules runAllManagedModulesForAllRequests="true" />
//  <httpProtocol>
//    <customHeaders>
//      <add name="Access-Control-Allow-Origin" value="*" />
//    </customHeaders>
//  </httpProtocol>
//</system.webServer>
// Factory="System.ServiceModel.Activation.WebServiceHostFactory" System.ServiceModel.Activation.WebScriptServiceHostFactory System.Web.ApplicationServices.ApplicationServicesHostFactory
// svc Factory WebServiceHostFactory


namespace Test_wcf_03.Service
{
    // RequirementsMode = AspNetCompatibilityRequirementsMode.Required
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service01 : IService01
    {
        static Service01()
        {
            if (Trace.CurrentTrace.GetLogFile() == null)
                Trace.CurrentTrace.SetLogFile(@"c:\pib\dev_data\iis\test_wcf_03\bin\log.txt", LogOptions.None);
            Trace.CurrentTrace.WriteLine("test Test_wcf_03.Service.Service01");

            Trace.CurrentTrace.WriteLine("current directory :\"{0}\"", System.IO.Directory.GetCurrentDirectory());

            System.Reflection.Assembly entryAssembly = System.Reflection.Assembly.GetEntryAssembly();
            string entryAssemblyName = null;
            string entryAssemblyLocation = null;
            if (entryAssembly != null)
            {
                entryAssemblyName = entryAssembly.FullName;
                entryAssemblyLocation = entryAssembly.Location;
            }
            Trace.CurrentTrace.WriteLine("EntryAssembly : \"{0}\" \"{1}\"", entryAssemblyName, entryAssemblyLocation);

            System.Reflection.Assembly executingAssembly = System.Reflection.Assembly.GetExecutingAssembly();
            string executingAssemblyName = null;
            string executingAssemblyLocation = null;
            if (executingAssembly != null)
            {
                executingAssemblyName = executingAssembly.FullName;
                executingAssemblyLocation = executingAssembly.Location;
            }
            Trace.CurrentTrace.WriteLine("ExecutingAssembly : \"{0}\" \"{1}\"", executingAssemblyName, executingAssemblyLocation);
        }

        public EmployeeXML GetEmployeeXML()
        {
            //Trace.CurrentTrace.SetLogFile(@"c:\pib\dev_data\iis\test_wcf_03\bin\log.txt", LogOptions.None);
            //Trace.CurrentTrace.WriteLine("test Test_wcf_03.Service.Service01");
            Trace.CurrentTrace.WriteLine("Service01.GetEmployeeXML()");
            EmployeeXML xml = new EmployeeXML() { Name = "toto", Id = 123, Salary = 4000.00 };
            return xml; ;
        }

        public EmployeeJSON GetEmployeeJSON()
        {
            //Trace.CurrentTrace.SetLogFile(@"c:\pib\dev_data\iis\test_wcf_03\bin\log.txt", LogOptions.None);
            //Trace.CurrentTrace.WriteLine("test Test_wcf_03.Service.Service01");
            Trace.CurrentTrace.WriteLine("Service01.GetEmployeeJSON()");
            EmployeeJSON json = new EmployeeJSON() { Name = "Sumanth", Id = 101, Salary = 5000.00 };
            return json;
        }
    }
}
