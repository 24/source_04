﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test_wcf_client.ServiceReference1;

namespace Test_wcf_client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Service1Client service1Client = null;
            try
            {
                WriteLine("create Service1Client");
                service1Client = new Service1Client();
                WriteLine("call service1Client.GetData(123)");
                string text = service1Client.GetData(123);
                WriteLine("result : \"{0}\"", text);
                CompositeType compositeType = new CompositeType { BoolValue = true, StringValue = "toto" };
                WriteLine("compositeType : BoolValue {0} StringValue \"{1}\"", compositeType.BoolValue, compositeType.StringValue);
                WriteLine("call service1Client.GetDataUsingDataContract(compositeType)");
                CompositeType newCompositeType = service1Client.GetDataUsingDataContract(compositeType);
                WriteLine("result : BoolValue {0} StringValue \"{1}\"", newCompositeType.BoolValue, newCompositeType.StringValue);
                WriteLine("close Service1Client");
                service1Client.Close();
                service1Client = null;
            }
            catch (Exception ex)
            {
                WriteLine("error : ");
                WriteLine(ex.Message);
                WriteLine(ex.StackTrace);
            }
            finally
            {
                if (service1Client != null)
                    service1Client.Close();
            }
        }

        private void WriteLine(string msg, params object[] prm)
        {
            if (prm.Length > 0)
                msg = string.Format(msg, prm);
            tb_log.AppendText(msg);
            tb_log.AppendText("\r\n");
        }
    }
}
