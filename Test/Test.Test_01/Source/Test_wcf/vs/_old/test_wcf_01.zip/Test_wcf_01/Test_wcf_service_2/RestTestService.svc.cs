﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace Test_wcf_service
{
    [ServiceContract(Namespace = "WcfAjaxServices")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class RestTestService
    {
        // To use HTTP GET, add [WebGet] attribute. (Default ResponseFormat is WebMessageFormat.Json)
        // To create an operation that returns XML,
        //     add [WebGet(ResponseFormat=WebMessageFormat.Xml)],
        //     and include the following line in the operation body:
        //         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml";

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json)]
        // result : "toto"
        public string GetString_Get()
        {
            return "toto";
        }

        [OperationContract]
        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, ResponseFormat = WebMessageFormat.Json)]
        // result : {"GetString_BodyWrappedResult":"toto"}
        public string GetString_Get_BodyWrapped()
        {
            return "toto";
        }

        [OperationContract]
        [WebInvoke(RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        // result : "toto"
        public string GetString_Post()
        {
            return "toto";
        }

        [OperationContract]
        [WebInvoke(BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        // result : {"GetString_Post_BodyWrappedResult":"toto"}
        public string GetString_Post_BodyWrapped()
        {
            return "toto";
        }

        [OperationContract]
        // BodyStyle = WebMessageBodyStyle.Wrapped
        [WebInvoke(RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        public Response PostTest()
        {
            return new Response() { A = "zozo", B = "zaza" };
        }

        //[OperationContract]
        //// BodyStyle = WebMessageBodyStyle.Wrapped
        //[WebInvoke(RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        //public Response PostTest(String a, String b)
        //{
        //    return (new Response() { A = a, B = b });
        //}

        //[OperationContract]
        //[WebGet(UriTemplate = "GetTest?a={a}&b={b}", ResponseFormat = WebMessageFormat.Json)]
        //public Response GetTestParam(String a, String b)
        //{
        //    return (new Response() { A = a, B = b });
        //}
    }
}
