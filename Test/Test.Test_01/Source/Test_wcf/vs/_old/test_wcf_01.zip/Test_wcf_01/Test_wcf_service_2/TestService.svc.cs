﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace Test_wcf_service
{
    // <%@ ServiceHost Language="C#" Debug="true" Service="Test_wcf_service.TestService" CodeBehind="TestService.svc.cs" %>
    // <%@ ServiceHost Language="C#" Debug="true" Service="WcfAjax.Services.TestService" CodeBehind="TestService.svc.cs" %>
    // Technically, you can go without using enableWebScript, if you specify a special factory in the .svc file
    // <%@ ServiceHost Language="C#" Debug="true" Factory="System.ServiceModel.Activation.WebScriptServiceHostFactory" Service="WcfAjax.Services.TestService" CodeBehind="TestService.svc.cs" %>

    [DataContract]
    public class Response
    {
        [DataMember]
        public String A { get; set; }
 
        [DataMember]
        public String B { get; set; }
    }

    [ServiceContract(Namespace = "WcfAjaxServices")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class TestService
    {
        [OperationContract]
        [WebInvoke]
        //[WebInvoke(BodyStyle = WebMessageBodyStyle.Wrapped, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        public Response PostTest(String a, String b)
        {
            return (new Response() { A = a, B = b });
        }
 
        [OperationContract]
        [WebGet]
        //[WebGet(UriTemplate = "GetTest?a={a}&b={b}", ResponseFormat = WebMessageFormat.Json)]
        public Response GetTest(String a, String b)
        {
            return (new Response() { A = a, B = b });
        }
    }
}
