﻿//$(document).ready(function () { });
function Clear() {
    $('#jsonData').html('');
}

function Test1() {
    $('#jsonData').html('');
    $('#jsonData').append("toto");
}

function Test2() {
    $('#jsonData').html('');
    $('#jsonData').append("tata");
}

function GetString_Get() {
    $.ajax({
        type: "GET",
        // http://localhost:4545/Service/Service1.svc/GetJson
        // http://localhost:8803/test_wcf_03/Service01.svc
        //url: "http://localhost:8803/test_wcf_03/Service01.svc/GetJson",
        //url: "http://localhost:8803/test_wcf_03/Service01/GetJson",
        url: "/RestTestService.svc/GetString_Get",
        contentType: "application/json;charset=utf-8",
        //dataType: "json",
        success: function (data) {
            //var result = data.GetEmployeeJSONResult;
            //var id = result.Id;
            //var name = result.Name;
            //var salary = result.Salary;
            $('#jsonData').html('');
            //$('#jsonData').append('<table border="1"><tbody><tr><th>' +
            //  "Employee Id</th><th>Name</th><th>Salary</th>" +
            //  '</tr><tr><td>' + id + '</td><td>' + name +
            //  '</td><td>' + salary + '</td></tr></tbody></table>');
            $('#jsonData').append(data);
        },
        error: function (xhr) {
            alert(xhr.responseText);
        }
    });
}


// from http://weblogs.asp.net/ricardoperes/calling-wcf-web-services-from-javascript
function restGetTest() {
    $.ajax
    (
        {
            type: 'GET',
            url: 'Services/RestTestService.svc/GetTest',
            dataType: 'json',
            data: 'a=a&b=b',
            success: function (response, type, xhr) {
                window.alert('A: ' + response.A);
            },
            error: function (xhr) {
                window.alert('error: ' + xhr.statusText);
            }
        }
    );

    $.ajax
    (
        {
            type: 'POST',
            url: 'Services/RestTestService.svc/PostTest',
            dataType: 'json',
            contentType: 'application/json',
            data: '{ "a": "a", "b": "b" }',
            success: function (response, type, xhr) {
                window.alert('A: ' + response.PostTestResult.A);
            },
            error: function (xhr) {
                window.alert('error: ' + xhr.statusText);
            }
        }
    );
}
