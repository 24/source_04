﻿using System;
using System.Windows.Forms;

// http://localhost:8701/Test_wcf_service_3/Service1/
// http://localhost:8701/Test_wcf_service_3/Service1/GetString_Get

namespace Test_wcf_service_3
{
    public partial class Form1 : Form
    {
        private ServiceHost _host = null;

        public Form1()
        {
            InitializeComponent();
            Trace.OnWrite += WriteText;
            _host = new ServiceHost();
        }

        private void StartService()
        {
            //Exec(() =>
            //{
            //    WriteLine("create ServiceHost(typeof(Service1))");
            //    _host = new ServiceHost(typeof(Service1));
            //    WriteLine("open ServiceHost");
            //    _host.Open();
            //    //this.bt_start_service.Enabled = false;
            //    WriteLine("service is started");
            //    WriteLine();
            //});
            StopService();
            Exec(_host.StartService);
        }

        private void StopService()
        {
            //if (_host != null)
            //{
            //    if (_host.State == CommunicationState.Opened || _host.State == CommunicationState.Faulted || _host.State == CommunicationState.Opening)
            //    {
            //        WriteLine("close ServiceHost");
            //        _host.Close();
            //        _host = null;
            //        //this.bt_start_service.Enabled = true;
            //        //this.lb_service.Text = "Service is stopped";
            //        WriteLine("service is stopped");
            //        WriteLine();
            //    }
            //}
            Exec(_host.StopService);
        }

        private void Exec(Action action)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                Trace.WriteLine(ex.StackTrace);
            }
        }

        private void WriteText(string msg)
        {
            this.tb_log.AppendText(msg);
        }

        //private void WriteLine()
        //{
        //    this.tb_log.AppendText("\r\n");
        //}

        //private void WriteLine(string msg, params object[] prm)
        //{
        //    if (prm.Length > 0)
        //        msg = string.Format(msg, prm);
        //    this.tb_log.AppendText(msg);
        //    WriteLine();
        //}

        private void bt_start_service_Click(object sender, EventArgs e)
        {
            StartService();
        }

        private void bt_stop_service_Click(object sender, EventArgs e)
        {
            StopService();
        }
    }
}
