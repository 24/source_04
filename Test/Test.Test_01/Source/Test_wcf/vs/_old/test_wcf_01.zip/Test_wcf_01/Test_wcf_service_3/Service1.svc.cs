﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;

namespace Test_wcf_service_3
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.

    //[ServiceContract(Namespace = "WcfAjaxServices")]
    [ServiceContract()]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service1
    {
        //public static void Configure(ServiceConfiguration config)
        //{
        //    //ServiceEndpoint se = new ServiceEndpoint(new ContractDescription("Service1"), new BasicHttpBinding(), new EndpointAddress("basic"));
        //    ServiceEndpoint serviceEndpoint = new ServiceEndpoint(new ContractDescription("Service1"), new WebHttpBinding(), new EndpointAddress("basic"));
        //    serviceEndpoint.Behaviors.Add(new MyEndpointBehavior());
        //    config.AddServiceEndpoint(serviceEndpoint);

        //    config.Description.Behaviors.Add(new ServiceMetadataBehavior { HttpGetEnabled = true });
        //    config.Description.Behaviors.Add(new ServiceDebugBehavior { IncludeExceptionDetailInFaults = true });
        //}

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json)]
        // result : "toto"
        public string GetString_Get()
        {
            return "toto";
        }

        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json)]
        // result : "toto"
        public string GetString_Get2()
        {
            // for all cors requests  
            WebOperationContext.Current.OutgoingResponse.Headers.Add("Access-Control-Allow-Origin", "*");
            // identify preflight request and add extra headers  
            if (WebOperationContext.Current.IncomingRequest.Method == "OPTIONS")
            {
                WebOperationContext.Current.OutgoingResponse.Headers.Add("Access-Control-Allow-Methods", "POST, OPTIONS, GET");
                WebOperationContext.Current.OutgoingResponse.Headers.Add("Access-Control-Allow-Headers", "Content-Type, Accept, Authorization, x-requested-with");
                return null;
            }
            else
                return "toto";
        }
    }
}
