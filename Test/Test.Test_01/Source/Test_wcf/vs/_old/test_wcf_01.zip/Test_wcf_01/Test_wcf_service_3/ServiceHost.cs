﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Test_wcf_service_3
{
    public class ServiceHost
    {
        private System.ServiceModel.ServiceHost _host = null;

        public void StartService()
        {
            StopService();
            Trace.WriteLine("create ServiceHost(typeof(Service1))");
            _host = new System.ServiceModel.ServiceHost(typeof(Service1));


            RestBinding binding = new RestBinding();

            //var serviceEndpoint = _host.AddServiceEndpoint(typeof(T), binding.WcfBinding, endpointAddress);
            //serviceEndpoint.Behaviors.Add(new WebHttpBehavior());
            //serviceEndpoint.Behaviors.Add(new FaultingWebHttpBehavior());
            //serviceEndpoint.Behaviors.Add(new EnableCorsEndpointBehavior());
            ////return serviceEndpoint;





            Trace.WriteLine("open ServiceHost");
            _host.Open();
            Trace.WriteLine("service is started");
            Trace.WriteLine();
        }

        public void StopService()
        {
            if (_host != null)
            {
                if (_host.State == CommunicationState.Opened || _host.State == CommunicationState.Faulted || _host.State == CommunicationState.Opening)
                {
                    Trace.WriteLine("close ServiceHost");
                    _host.Close();
                    _host = null;
                    Trace.WriteLine("service is stopped");
                    Trace.WriteLine();
                }
            }
        }
    }

    public class RestBinding : WebHttpBinding
    {
        private const string __schema = "http://www.konfdb.com/schemas";
        private const string __serviceName = "ServiceBinding";

        public RestBinding()
        {
            this.Namespace = __schema;  // ServiceConstants.Schema
            this.Name = __serviceName;  // ServiceConstants.ServiceName
            this.CrossDomainScriptAccessEnabled = true;
        }
    }
}
