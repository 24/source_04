﻿using System;

namespace Test_wcf_service_3
{
    public static class Trace
    {
        public static Action<string> OnWrite = null;

        public static void Write(string msg)
        {
            OnWrite(msg);
        }

        public static void Write(string msg, params object[] prm)
        {
            if (prm.Length > 0)
                msg = string.Format(msg, prm);
            Write(msg);
        }

        public static void WriteLine()
        {
            Write("\r\n");
        }

        public static void WriteLine(string msg)
        {
            Write(msg);
            WriteLine();
        }

        public static void WriteLine(string msg, params object[] prm)
        {
            if (prm.Length > 0)
                msg = string.Format(msg, prm);
            Write(msg);
            WriteLine();
        }
    }
}
