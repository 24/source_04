﻿using System;
using System.Windows.Forms;

// http://localhost:8701/Test_wcf_service_3/Service1/
// http://localhost:8701/Test_wcf_service_3/Service1/GetString_Get

namespace Test_wcf_service_4
{
    public partial class Form1 : Form
    {
        private ServiceHost _host = null;

        public Form1()
        {
            InitializeComponent();
            Trace.OnWrite += WriteText;
            _host = new ServiceHost();
        }

        private void StartService()
        {
            StopService();
            Exec(_host.StartService);
        }

        private void StopService()
        {
            Exec(_host.StopService);
        }

        private void Exec(Action action)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                Trace.WriteLine(ex.StackTrace);
            }
        }

        private void WriteText(string msg)
        {
            this.tb_log.AppendText(msg);
        }

        private void bt_start_service_Click(object sender, EventArgs e)
        {
            StartService();
        }

        private void bt_stop_service_Click(object sender, EventArgs e)
        {
            StopService();
        }
    }
}
