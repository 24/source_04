﻿using System;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

namespace Test_wcf_service_4
{
    [ServiceContract()]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service1
    {
        [OperationContract]
        [WebGet(ResponseFormat = WebMessageFormat.Json)]
        // result : "toto"
        public string GetString_Get()
        {
            return "toto";
        }
    }
}
