﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace Test_wcf_service_4
{
    public class ServiceHost
    {
        private System.ServiceModel.ServiceHost _host = null;

        public void StartService()
        {
            StopService();
            Trace.WriteLine("create ServiceHost(typeof(Service1))");
            _host = new System.ServiceModel.ServiceHost(typeof(Service1), new Uri("http://localhost:8701/test_wcf_service_4/"));

            // Service 'Test_wcf_service_4.Service1' has zero application (non-infrastructure) endpoints.
            // This might be because no configuration file was found for your application,
            // or because no service element matching the service name could be found in the configuration file,
            // or because no endpoints were defined in the service element.

            // Could not find a base address that matches scheme http for the endpoint with binding WebHttpBinding. Registered base address schemes are [].
            WebHttpBinding webHttpBinding = new WebHttpBinding();
            ServiceEndpoint serviceEndpoint = _host.AddServiceEndpoint(typeof(Service1), webHttpBinding, "service1");
            serviceEndpoint.Behaviors.Add(new WebHttpBehavior());
            //_host.SetEndpointAddress();
            //_host.BaseAddresses

            ServiceMetadataBehavior serviceMetadataBehavior = new ServiceMetadataBehavior();
            serviceMetadataBehavior.HttpGetEnabled = true;
            serviceMetadataBehavior.MetadataExporter.PolicyVersion = PolicyVersion.Policy15;
            _host.Description.Behaviors.Add(serviceMetadataBehavior);

            Trace.WriteLine("open ServiceHost");
            _host.Open();
            Trace.WriteLine("service is started");
            Trace.WriteLine();
        }

        public void StopService()
        {
            if (_host != null)
            {
                if (_host.State == CommunicationState.Opened || _host.State == CommunicationState.Faulted || _host.State == CommunicationState.Opening)
                {
                    Trace.WriteLine("close ServiceHost");
                    _host.Close();
                    _host = null;
                    Trace.WriteLine("service is stopped");
                    Trace.WriteLine();
                }
            }
        }
    }
}
