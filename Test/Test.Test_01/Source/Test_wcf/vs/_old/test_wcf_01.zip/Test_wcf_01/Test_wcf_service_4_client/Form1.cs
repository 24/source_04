﻿using System;
using System.Windows.Forms;

// http://localhost:8701/Test_wcf_service_3/Service1/
// http://localhost:8701/Test_wcf_service_3/Service1/GetString_Get

namespace Test_wcf_service_4_client
{
    public partial class Form1 : Form
    {
        private ServiceReference1.Service1Client _service1Client = null;
        private string _service1ClientConfigurationName = null; //  "Service1Client"
        private string _service1ClientRemoteAddress = "http://localhost:8701/test_wcf_service_4/";

        public Form1()
        {
            InitializeComponent();
            Trace.OnWrite += WriteText;
        }

        private void OpenService1Client()
        {
            CloseService1Client();
            Exec(() =>
                {
                    Trace.WriteLine("create ServiceReference1.Service1Client");
                    _service1Client = new ServiceReference1.Service1Client(_service1ClientConfigurationName, _service1ClientRemoteAddress);
                    Trace.WriteLine("open ServiceReference1.Service1Client");
                    _service1Client.Open();
                    Trace.WriteLine();
                });
        }

        private void CloseService1Client()
        {
            Exec(() =>
                {
                    if (_service1Client != null)
                    {
                        Trace.WriteLine("close ServiceReference1.Service1Client");
                        _service1Client.Close();
                        _service1Client = null;
                        Trace.WriteLine();
                    }
                });
        }

        private void CallService1Client_GetString_Get()
        {
            Exec(() =>
            {
                if (_service1Client != null)
                {
                    Trace.WriteLine("call ServiceReference1.Service1Client.GetString_Get()");
                    string s = _service1Client.GetString_Get();
                    Trace.WriteLine("result : \"{0}\"", s);
                    Trace.WriteLine();
                }
            });
        }

        private void Exec(Action action)
        {
            try
            {
                action();
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.Message);
                Trace.WriteLine(ex.StackTrace);
            }
        }

        private void WriteText(string msg)
        {
            this.tb_log.AppendText(msg);
        }

        private void bt_open_service1_client_Click(object sender, EventArgs e)
        {
            OpenService1Client();
        }

        private void bt_close_service1_client_Click(object sender, EventArgs e)
        {
            CloseService1Client();
        }

        private void bt_call_getstring_get_Click(object sender, EventArgs e)
        {
            CallService1Client_GetString_Get();
        }
    }
}
